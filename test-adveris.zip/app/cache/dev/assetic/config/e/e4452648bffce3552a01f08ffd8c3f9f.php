<?php

// :admin:edit_actu.html.twig
return array (
);
