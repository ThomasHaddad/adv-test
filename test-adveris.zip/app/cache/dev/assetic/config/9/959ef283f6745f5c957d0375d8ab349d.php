<?php

// :admin:manage_actu.html.twig
return array (
);
