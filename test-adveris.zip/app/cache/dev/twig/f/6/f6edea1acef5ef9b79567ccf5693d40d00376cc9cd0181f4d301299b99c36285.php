<?php

/* base.html.twig */
class __TwigTemplate_f6edea1acef5ef9b79567ccf5693d40d00376cc9cd0181f4d301299b99c36285 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'main_content' => array($this, 'block_main_content'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_85104dffd28e6ba7e2a27eb872d513497c64f231c5344d302a11edeaf8d98453 = $this->env->getExtension("native_profiler");
        $__internal_85104dffd28e6ba7e2a27eb872d513497c64f231c5344d302a11edeaf8d98453->enter($__internal_85104dffd28e6ba7e2a27eb872d513497c64f231c5344d302a11edeaf8d98453_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\"/>
    <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>
<body>
<div class=\"container\">
    <nav class=\"navbar navbar-fixed-top\">
        <div class=\"container\">
            <img src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("images/logo.jpg"), "html", null, true);
        echo "\" alt=\"\"/>
            <ul class=\"nav navbar-nav navbar-left   \">
                <li><a href=\"";
        // line 18
        echo $this->env->getExtension('routing')->getPath("index");
        echo "\" title=\"accueil\">Accueil</a></li>
                <li><a href=\"#\" title=\"services\">Les services</a></li>
                <li><a href=\"#\" title=\"network\">Le réseau</a></li>
                <li><a href=\"#\" title=\"sitemap\">Plan du site</a></li>
                <li><a href=\"#\" title=\"contact\">Nous contacter</a></li>
            </ul>
            <ul class=\"nav navbar-nav navbar-right\">
                ";
        // line 25
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 26
            echo "
                    <li role=\"presentation\"><a href=\"\"><span
                                    class=\"glyphicon glyphicon-user \"></span>Bienvenue ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo "</a></li>
                    <li role=\"presentation\"><a href=\"";
            // line 29
            echo $this->env->getExtension('routing')->getPath("editHomepage");
            echo "\" title=\"edit\">Gérer le contenu</a></li>
                    <li role=\"presentation\"><a href=\"";
            // line 30
            echo $this->env->getExtension('routing')->getPath("logout");
            echo "\" title=\"deconnexion\">Déconnexion</a></li>
                ";
        } else {
            // line 32
            echo "                    <li role=\"presentation\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("register");
            echo "\" title=\"inscription\">Inscription</a></li>
                    <li role=\"presentation\"><a href=\"";
            // line 33
            echo $this->env->getExtension('routing')->getPath("login");
            echo "\" title=\"connexion\">Connexion</a></li>
                ";
        }
        // line 35
        echo "            </ul>
        </div>
    </nav>
    <div class=\"container\" style=\"margin-top:100px;\">

        ";
        // line 40
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 41
            echo "            <div class=\"alert alert-success\">
                ";
            // line 42
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "        ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 46
            echo "            <div class=\"alert alert-danger\">
                ";
            // line 47
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "
        ";
        // line 51
        $this->displayBlock('main_content', $context, $blocks);
        // line 52
        echo "    </div>
</div>
    ";
        // line 54
        $this->displayBlock('footer', $context, $blocks);
        // line 66
        $this->displayBlock('javascripts', $context, $blocks);
        // line 70
        echo "</body>
</html>";
        
        $__internal_85104dffd28e6ba7e2a27eb872d513497c64f231c5344d302a11edeaf8d98453->leave($__internal_85104dffd28e6ba7e2a27eb872d513497c64f231c5344d302a11edeaf8d98453_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_b2b5bff21d239df7266e44ba7a344c766308aaedbaea49bda4b10688017da54d = $this->env->getExtension("native_profiler");
        $__internal_b2b5bff21d239df7266e44ba7a344c766308aaedbaea49bda4b10688017da54d->enter($__internal_b2b5bff21d239df7266e44ba7a344c766308aaedbaea49bda4b10688017da54d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "AAS BUILDING";
        
        $__internal_b2b5bff21d239df7266e44ba7a344c766308aaedbaea49bda4b10688017da54d->leave($__internal_b2b5bff21d239df7266e44ba7a344c766308aaedbaea49bda4b10688017da54d_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_55512adb36f3413d0cc0270e04d51a64ee2a7bcd5272f40f7e3b394fbb4855fe = $this->env->getExtension("native_profiler");
        $__internal_55512adb36f3413d0cc0270e04d51a64ee2a7bcd5272f40f7e3b394fbb4855fe->enter($__internal_55512adb36f3413d0cc0270e04d51a64ee2a7bcd5272f40f7e3b394fbb4855fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\"/>
        <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\"/>
    ";
        
        $__internal_55512adb36f3413d0cc0270e04d51a64ee2a7bcd5272f40f7e3b394fbb4855fe->leave($__internal_55512adb36f3413d0cc0270e04d51a64ee2a7bcd5272f40f7e3b394fbb4855fe_prof);

    }

    // line 51
    public function block_main_content($context, array $blocks = array())
    {
        $__internal_4beb649441333d79fb387b6efec3ba87329aeebe471c07ef36b9388f38b89d55 = $this->env->getExtension("native_profiler");
        $__internal_4beb649441333d79fb387b6efec3ba87329aeebe471c07ef36b9388f38b89d55->enter($__internal_4beb649441333d79fb387b6efec3ba87329aeebe471c07ef36b9388f38b89d55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main_content"));

        
        $__internal_4beb649441333d79fb387b6efec3ba87329aeebe471c07ef36b9388f38b89d55->leave($__internal_4beb649441333d79fb387b6efec3ba87329aeebe471c07ef36b9388f38b89d55_prof);

    }

    // line 54
    public function block_footer($context, array $blocks = array())
    {
        $__internal_be4435301f038b3c939f2c1f1421168b6b8e6cd7f7c24dec63c4e13cc3b01f31 = $this->env->getExtension("native_profiler");
        $__internal_be4435301f038b3c939f2c1f1421168b6b8e6cd7f7c24dec63c4e13cc3b01f31->enter($__internal_be4435301f038b3c939f2c1f1421168b6b8e6cd7f7c24dec63c4e13cc3b01f31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 55
        echo "        <footer class=\"footer\">
            <div class=\"container\">
                <ul class=\"nav navbar-nav\">
                    <li><a href=\"\">Lien 1</a></li>
                    <li><a href=\"\">Lien 2</a></li>
                    <li><a href=\"\">Lien 3</a></li>
                    <li><a href=\"\">Lien 4</a></li>
                </ul>
            </div>
        </footer>
    ";
        
        $__internal_be4435301f038b3c939f2c1f1421168b6b8e6cd7f7c24dec63c4e13cc3b01f31->leave($__internal_be4435301f038b3c939f2c1f1421168b6b8e6cd7f7c24dec63c4e13cc3b01f31_prof);

    }

    // line 66
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_ab177ca2589e6aeda3c1a327bcfd109d72d97f8d481b794890f9287a186b0c1f = $this->env->getExtension("native_profiler");
        $__internal_ab177ca2589e6aeda3c1a327bcfd109d72d97f8d481b794890f9287a186b0c1f->enter($__internal_ab177ca2589e6aeda3c1a327bcfd109d72d97f8d481b794890f9287a186b0c1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 67
        echo "    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js\"></script>
    <script src=\"";
        // line 68
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_ab177ca2589e6aeda3c1a327bcfd109d72d97f8d481b794890f9287a186b0c1f->leave($__internal_ab177ca2589e6aeda3c1a327bcfd109d72d97f8d481b794890f9287a186b0c1f_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  229 => 68,  226 => 67,  220 => 66,  203 => 55,  197 => 54,  186 => 51,  177 => 8,  172 => 7,  166 => 6,  154 => 5,  146 => 70,  144 => 66,  142 => 54,  138 => 52,  136 => 51,  133 => 50,  124 => 47,  121 => 46,  116 => 45,  107 => 42,  104 => 41,  100 => 40,  93 => 35,  88 => 33,  83 => 32,  78 => 30,  74 => 29,  70 => 28,  66 => 26,  64 => 25,  54 => 18,  49 => 16,  39 => 10,  37 => 6,  33 => 5,  27 => 1,);
    }
}
