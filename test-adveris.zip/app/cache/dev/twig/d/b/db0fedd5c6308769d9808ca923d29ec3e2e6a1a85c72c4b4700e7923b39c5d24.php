<?php

/* default/index.html.twig */
class __TwigTemplate_db0fedd5c6308769d9808ca923d29ec3e2e6a1a85c72c4b4700e7923b39c5d24 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'main_content' => array($this, 'block_main_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_039ab12652827fceab09e421792116f4664c8227b535a0c16ef8614d43e25c7f = $this->env->getExtension("native_profiler");
        $__internal_039ab12652827fceab09e421792116f4664c8227b535a0c16ef8614d43e25c7f->enter($__internal_039ab12652827fceab09e421792116f4664c8227b535a0c16ef8614d43e25c7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_039ab12652827fceab09e421792116f4664c8227b535a0c16ef8614d43e25c7f->leave($__internal_039ab12652827fceab09e421792116f4664c8227b535a0c16ef8614d43e25c7f_prof);

    }

    // line 3
    public function block_main_content($context, array $blocks = array())
    {
        $__internal_989a56f231b8ec4c98608ef2f57770b80f769849c4b029d7bfa9a7a746ce422b = $this->env->getExtension("native_profiler");
        $__internal_989a56f231b8ec4c98608ef2f57770b80f769849c4b029d7bfa9a7a746ce422b->enter($__internal_989a56f231b8ec4c98608ef2f57770b80f769849c4b029d7bfa9a7a746ce422b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main_content"));

        // line 4
        echo "    ";
        if ((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info"))) {
            // line 5
            echo "        <h1 class=\"text-center text-uppercase\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "content", array()), "html", null, true);
            echo "</h1>
    ";
        } else {
            // line 7
            echo "        <h1 class=\"text-center text-uppercase\">Titre par défaut de la Homepage</h1>
    ";
        }
        // line 9
        echo "    <main>

        <section>
            <h2 class=\"text-center text-uppercase\">Nos 32 points d'implantation</h2>
            <p class=\"text-center\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab, accusantium aliquam commodi culpa dicta eaque, est facilis illum iusto magnam recusandae sequi soluta! Amet iusto, magni quis saepe sequi voluptate?</p>
            <img src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("images/france.gif"), "html", null, true);
        echo "\" alt=\"la france\"/>
        </section>
        <section>
            <h2 class=\"text-center text-uppercase\">Infos</h2>
            <p class=\"text-center\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo inventore ipsam laudantium natus. Ad consequatur corporis earum error facere incidunt laudantium quae repellendus ut velit. Cumque inventore minima sed sit.</p>
            <img src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("images/paris.gif"), "html", null, true);
        echo "\" alt=\"le paris\"/>
        </section>
    </main>
";
        
        $__internal_989a56f231b8ec4c98608ef2f57770b80f769849c4b029d7bfa9a7a746ce422b->leave($__internal_989a56f231b8ec4c98608ef2f57770b80f769849c4b029d7bfa9a7a746ce422b_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 19,  60 => 14,  53 => 9,  49 => 7,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
