<?php

/* user/register.html.twig */
class __TwigTemplate_8a784e393647a2a25c8b4e601579e7f91657aa6f8abe39222b0d2e3672f245ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/register.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'main_content' => array($this, 'block_main_content'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_caf7e2c9b4aa24bcda25badd299f711f43dd3135d8aa4fb983240ef700aec985 = $this->env->getExtension("native_profiler");
        $__internal_caf7e2c9b4aa24bcda25badd299f711f43dd3135d8aa4fb983240ef700aec985->enter($__internal_caf7e2c9b4aa24bcda25badd299f711f43dd3135d8aa4fb983240ef700aec985_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_caf7e2c9b4aa24bcda25badd299f711f43dd3135d8aa4fb983240ef700aec985->leave($__internal_caf7e2c9b4aa24bcda25badd299f711f43dd3135d8aa4fb983240ef700aec985_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_13902117380f808e6a5208ab169d13b307f93585b370ec45156efe47d775b51c = $this->env->getExtension("native_profiler");
        $__internal_13902117380f808e6a5208ab169d13b307f93585b370ec45156efe47d775b51c->enter($__internal_13902117380f808e6a5208ab169d13b307f93585b370ec45156efe47d775b51c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Inscription | ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_13902117380f808e6a5208ab169d13b307f93585b370ec45156efe47d775b51c->leave($__internal_13902117380f808e6a5208ab169d13b307f93585b370ec45156efe47d775b51c_prof);

    }

    // line 7
    public function block_main_content($context, array $blocks = array())
    {
        $__internal_5ff7a62d23ef806c7f9632437c240c3fb2d681a242458402703fb076ca5bef33 = $this->env->getExtension("native_profiler");
        $__internal_5ff7a62d23ef806c7f9632437c240c3fb2d681a242458402703fb076ca5bef33->enter($__internal_5ff7a62d23ef806c7f9632437c240c3fb2d681a242458402703fb076ca5bef33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main_content"));

        // line 8
        echo "
    <h1>Inscription</h1>

    ";
        // line 11
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["registerForm"]) ? $context["registerForm"] : $this->getContext($context, "registerForm")), 'form', array("attr" => array("novalidate" => "novalidate")));
        echo "

";
        
        $__internal_5ff7a62d23ef806c7f9632437c240c3fb2d681a242458402703fb076ca5bef33->leave($__internal_5ff7a62d23ef806c7f9632437c240c3fb2d681a242458402703fb076ca5bef33_prof);

    }

    // line 15
    public function block_footer($context, array $blocks = array())
    {
        $__internal_7c0ae9a0044521486dacf26eda435b3be3872538cd733462656c5aad43b4747e = $this->env->getExtension("native_profiler");
        $__internal_7c0ae9a0044521486dacf26eda435b3be3872538cd733462656c5aad43b4747e->enter($__internal_7c0ae9a0044521486dacf26eda435b3be3872538cd733462656c5aad43b4747e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        
        $__internal_7c0ae9a0044521486dacf26eda435b3be3872538cd733462656c5aad43b4747e->leave($__internal_7c0ae9a0044521486dacf26eda435b3be3872538cd733462656c5aad43b4747e_prof);

    }

    public function getTemplateName()
    {
        return "user/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 15,  63 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }
}
