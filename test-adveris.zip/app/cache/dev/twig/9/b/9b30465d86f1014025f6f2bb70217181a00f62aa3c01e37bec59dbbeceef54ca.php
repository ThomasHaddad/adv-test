<?php

/* admin/edit_homepage.html.twig */
class __TwigTemplate_9b30465d86f1014025f6f2bb70217181a00f62aa3c01e37bec59dbbeceef54ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "admin/edit_homepage.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'main_content' => array($this, 'block_main_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a4ceebbdf136e93012f56378f7e7593c041e45b5f29722b03ce5fd98dd8fbb9c = $this->env->getExtension("native_profiler");
        $__internal_a4ceebbdf136e93012f56378f7e7593c041e45b5f29722b03ce5fd98dd8fbb9c->enter($__internal_a4ceebbdf136e93012f56378f7e7593c041e45b5f29722b03ce5fd98dd8fbb9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/edit_homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a4ceebbdf136e93012f56378f7e7593c041e45b5f29722b03ce5fd98dd8fbb9c->leave($__internal_a4ceebbdf136e93012f56378f7e7593c041e45b5f29722b03ce5fd98dd8fbb9c_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_14fe9e53dadc36622de383f147b061a76b9df2a6d008923ffdef41ee4b5ef76c = $this->env->getExtension("native_profiler");
        $__internal_14fe9e53dadc36622de383f147b061a76b9df2a6d008923ffdef41ee4b5ef76c->enter($__internal_14fe9e53dadc36622de383f147b061a76b9df2a6d008923ffdef41ee4b5ef76c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "     Modification | ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_14fe9e53dadc36622de383f147b061a76b9df2a6d008923ffdef41ee4b5ef76c->leave($__internal_14fe9e53dadc36622de383f147b061a76b9df2a6d008923ffdef41ee4b5ef76c_prof);

    }

    // line 7
    public function block_main_content($context, array $blocks = array())
    {
        $__internal_9fef8a408acd1135668141ac3c529b8fe349dff15cda92ed07e5015e54248c5f = $this->env->getExtension("native_profiler");
        $__internal_9fef8a408acd1135668141ac3c529b8fe349dff15cda92ed07e5015e54248c5f->enter($__internal_9fef8a408acd1135668141ac3c529b8fe349dff15cda92ed07e5015e54248c5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main_content"));

        // line 8
        echo "   <h1>Modification des informations la homepage</h1>
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["infoForm"]) ? $context["infoForm"] : $this->getContext($context, "infoForm")), 'form', array("attr" => array("novalidate" => "novalidate")));
        echo "
";
        
        $__internal_9fef8a408acd1135668141ac3c529b8fe349dff15cda92ed07e5015e54248c5f->leave($__internal_9fef8a408acd1135668141ac3c529b8fe349dff15cda92ed07e5015e54248c5f_prof);

    }

    public function getTemplateName()
    {
        return "admin/edit_homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 9,  57 => 8,  51 => 7,  41 => 4,  35 => 3,  11 => 1,);
    }
}
