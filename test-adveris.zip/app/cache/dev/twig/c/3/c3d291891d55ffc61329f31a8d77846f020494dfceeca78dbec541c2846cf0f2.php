<?php

/* user/login.html.twig */
class __TwigTemplate_c3d291891d55ffc61329f31a8d77846f020494dfceeca78dbec541c2846cf0f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/login.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'main_content' => array($this, 'block_main_content'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f596f4378cdc37347920a46748296baadbe58622576783109f66c173e9a2abd1 = $this->env->getExtension("native_profiler");
        $__internal_f596f4378cdc37347920a46748296baadbe58622576783109f66c173e9a2abd1->enter($__internal_f596f4378cdc37347920a46748296baadbe58622576783109f66c173e9a2abd1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f596f4378cdc37347920a46748296baadbe58622576783109f66c173e9a2abd1->leave($__internal_f596f4378cdc37347920a46748296baadbe58622576783109f66c173e9a2abd1_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_61d82efb2dda79b6333626d8f5c73df6578837ea46c3a1b8dd0bbc6fa5aceba7 = $this->env->getExtension("native_profiler");
        $__internal_61d82efb2dda79b6333626d8f5c73df6578837ea46c3a1b8dd0bbc6fa5aceba7->enter($__internal_61d82efb2dda79b6333626d8f5c73df6578837ea46c3a1b8dd0bbc6fa5aceba7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Connexion | ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_61d82efb2dda79b6333626d8f5c73df6578837ea46c3a1b8dd0bbc6fa5aceba7->leave($__internal_61d82efb2dda79b6333626d8f5c73df6578837ea46c3a1b8dd0bbc6fa5aceba7_prof);

    }

    // line 7
    public function block_main_content($context, array $blocks = array())
    {
        $__internal_a671b8492694852b72919e72b28017bc9155c80f8d87aed7355ff760ce7d18b2 = $this->env->getExtension("native_profiler");
        $__internal_a671b8492694852b72919e72b28017bc9155c80f8d87aed7355ff760ce7d18b2->enter($__internal_a671b8492694852b72919e72b28017bc9155c80f8d87aed7355ff760ce7d18b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main_content"));

        // line 8
        echo "<div class=\"container\" style=\"width:400px;\">


    ";
        // line 11
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 12
            echo "        <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array())), "html", null, true);
            echo "</div>
    ";
        }
        // line 14
        echo "
    <form action=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("login_check");
        echo "\" method=\"post\" class=\"form-signin\">
        <h2 class=\"form-signin-heading\">Connexion</h2>
        <label class=\"sr-only\" for=\"username\">Username:</label>
        <input class=\"form-control\" type=\"text\" id=\"username\" name=\"_username\" placeholder=\"Pseudo\" value=\"";
        // line 18
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" />

        <label class=\"sr-only\" for=\"password\">Password:</label>
        <input class=\"form-control\" type=\"password\" id=\"password\" placeholder=\"Mot de passe\" name=\"_password\" />


        <div class=\"checkbox\">
            <label for=\"\">
                <input type=\"checkbox\" value=\"remember-me\"/> Se souvenir de moi
            </label>
        </div>
        <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">login</button>

    </form>
</div>

";
        
        $__internal_a671b8492694852b72919e72b28017bc9155c80f8d87aed7355ff760ce7d18b2->leave($__internal_a671b8492694852b72919e72b28017bc9155c80f8d87aed7355ff760ce7d18b2_prof);

    }

    // line 36
    public function block_footer($context, array $blocks = array())
    {
        $__internal_5e1861eed1395dfe2ecc5cc76a2496de15800959c089d2c3b2e6e1e347b55075 = $this->env->getExtension("native_profiler");
        $__internal_5e1861eed1395dfe2ecc5cc76a2496de15800959c089d2c3b2e6e1e347b55075->enter($__internal_5e1861eed1395dfe2ecc5cc76a2496de15800959c089d2c3b2e6e1e347b55075_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        
        $__internal_5e1861eed1395dfe2ecc5cc76a2496de15800959c089d2c3b2e6e1e347b55075->leave($__internal_5e1861eed1395dfe2ecc5cc76a2496de15800959c089d2c3b2e6e1e347b55075_prof);

    }

    public function getTemplateName()
    {
        return "user/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 36,  80 => 18,  74 => 15,  71 => 14,  65 => 12,  63 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }
}
