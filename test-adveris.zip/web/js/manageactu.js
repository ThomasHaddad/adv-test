$('.delete').on('click',function(){
    return confirm('Voulez vous vraiment supprimer l\'actu selectionnée?');
});